const Listing = require("../models/listing");  // Import the Listing model
const Review = require("../models/review");  // Import the Review model

// Function to calculate the average rating of a listing
const calculateAverageRating = (reviews) => {
    if (reviews.length === 0) return 0;
    const total = reviews.reduce((accum, review) => accum + review.rating, 0);
    return total / reviews.length;
};

module.exports.index = async (req, res) => {
    const { search } = req.query;  // Get search query from request

    let allListings;
    
    if (search) {
        // Fetch listings matching the search query
        allListings = await Listing.find({ title: { $regex: search, $options: "i" } })
            .populate("reviews");  // Populate reviews to calculate the average rating
        if (allListings.length === 0) {
            req.flash("error", "No listings found matching your search criteria.");
        }
    } else {
        // Fetch all listings and populate their reviews
        allListings = await Listing.find({}).populate("reviews");
    }

    // Calculate the average rating for each listing
    allListings.forEach(listing => {
        listing.averageRating = calculateAverageRating(listing.reviews);
    });

    // Sort the listings by average rating (highest first)
    allListings = allListings.sort((a, b) => b.averageRating - a.averageRating);

    // Render the listings page with sorted listings
    res.render("listings/index", { allListings });
};

module.exports.renderNewForm = (req, res) => {
    res.render("listings/new");  // Render form to create a new listing
};

module.exports.showListing = async (req, res) => {
    // Find the listing by id and populate associated reviews and owner
    const listing = await Listing.findById(req.params.id)
        .populate({
            path: "reviews",
            populate: { path: "author" },  // Populate review authors
        })
        .populate("owner");

    if (!listing) {
        req.flash("error", "Listing you requested does not exist!");
        return res.redirect("/listings");
    }

    res.render("listings/show", { listing });  // Render listing details page
};

module.exports.createListing = async (req, res) => {
    const newListing = new Listing(req.body.listing);
    newListing.owner = req.user._id;  // Set owner as current user
    await newListing.save();
    req.flash("success", "New Listing Created");
    res.redirect(`/listings/${newListing._id}`);
};

module.exports.renderEditForm = async (req, res) => {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
        req.flash("error", "Listing not found!");
        return res.redirect("/listings");
    }

    res.render("listings/edit", { listing });
};

module.exports.updateListing = async (req, res) => {
    const { id } = req.params;
    const updatedListing = await Listing.findByIdAndUpdate(id, req.body.listing, { new: true });
    req.flash("success", "Listing Updated");
    res.redirect(`/listings/${updatedListing._id}`);
};

module.exports.destroyListing = async (req, res) => {
    const { id } = req.params;
    await Listing.findByIdAndDelete(id);
    req.flash("success", "Listing Deleted");
    res.redirect("/listings");
};
