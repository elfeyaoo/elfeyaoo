// user.js
const User = require("../models/user");  // Import the User model
const Review = require("../models/review");  // Import the Review model

module.exports.renderSignupForm = (req, res) => {
    // Render signup form page
    res.render("users/signup.ejs");
}

module.exports.signup = async (req, res) => {
    let { username, email, password } = req.body;  // Extract form data
    const newUser = new User({ email, username });  // Create a new user instance
    try {
        const registeredUser = await User.register(newUser, password);  // Register user with hashed password
        console.log(registeredUser);  // Log the registered user for verification
        req.login(registeredUser, (err) => {
            if (err) {
                return next(err);
            }
            req.flash("success", "Welcome to Peaceful Places");  // Show success message
            res.redirect("/listings");  // Redirect to listings page
        });
    } catch (e) {
        req.flash("error", e.message);  // Show error message
        res.redirect("/signup");  // Redirect to signup form
    }
}

module.exports.renderLoginForm = (req, res) => {
    // Render login form page
    res.render("users/login.ejs");
}

module.exports.login = async (req, res) => {
    req.flash("success", "Welcome to Peaceful Places! You are logged in!");  // Show success message
    res.redirect("/listings");  // Redirect to listings page
}

module.exports.logout = (req, res) => {
    req.logout((err) => {
        if (err) {
            return next(err);  // Handle any errors during logout
        }
        req.flash("success", "You are logged out!");  // Show success message
        res.redirect("/listings");  // Redirect to listings page
    });
}
