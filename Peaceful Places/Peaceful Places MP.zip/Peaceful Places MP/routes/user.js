const express = require("express");  // Import express to create a router
const router = express.Router();  // Create a router instance
const User = require("../models/user.js");  // Import the User model
const wrapAsync = require("../utils/wrapAsync");  // Utility function to handle async errors
const passport = require("passport");  // Import passport for authentication
const { saveRedirectUrl } = require("../middleware.js");  // Import middleware to save redirect URL after login
const userController = require("../controllers/users.js");  // Import the users controller

// Routes for signup (registration)
router.route("/signup")
.get(userController.renderSignupForm)  // GET request to render signup form
.post(wrapAsync(userController.signup));  // POST request to register a new user

// Routes for login
router.route("/login")
.get(userController.renderLoginForm)  // GET request to render login form
.post(
    saveRedirectUrl,  // Middleware to save the URL the user wanted to access before logging in
    passport.authenticate("local",  // Authenticate using 'local' strategy provided by passport-local-mongoose
    {
        failureRedirect: '/login',  // Redirect to login if authentication fails
        failureFlash: true  // Flash an error message if authentication fails
    }),
    userController.login  // If authentication is successful, call the login controller function
);

// Route for logout
router.get("/logout", userController.logout);  // GET request to log the user out

module.exports = router;  // Export the router for use in other parts of the application
