const mongoose = require("mongoose");  // Import mongoose to define the schema and interact with MongoDB
const Schema = mongoose.Schema;  // Create a schema object for defining the review model

// Define the schema for a review
const reviewSchema = new Schema({
    comment: String,  // The text comment provided by the reviewer
    rating: {
        type: Number,  // Rating is a number field
        min: 1,  // Minimum rating value allowed is 1
        max: 5,  // Maximum rating value allowed is 5
    },
    createdAt: {
        type: Date,  // Date when the review was created
        default: Date.now()  // Default value is the current date and time
    },
    author: {
        type: Schema.Types.ObjectId,  // Reference to the user who wrote the review
        ref: "User",  // Refers to the User model
    },
});

// Export the Review model so it can be used in other parts of the application
module.exports = mongoose.model("Review", reviewSchema);
