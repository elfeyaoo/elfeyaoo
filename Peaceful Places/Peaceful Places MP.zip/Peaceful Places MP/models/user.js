const mongoose = require("mongoose");  // Import mongoose to define the schema and interact with MongoDB
const Schema = mongoose.Schema;  // Create a schema object for defining the user model
const passportLocalMongoose = require("passport-local-mongoose");  // Import passport-local-mongoose for handling authentication

// Define the schema for a user
const userSchema = new Schema({
    email: {
        type: String,  // User's email
        required: true  // Email is required for each user
    }
});

// Plugin passportLocalMongoose adds fields for username and hashed password automatically
userSchema.plugin(passportLocalMongoose);  // This plugin simplifies user authentication by adding username, password, and authentication methods

// Export the User model so it can be used in other parts of the application
module.exports = mongoose.model('User', userSchema);
