const express = require("express");
const router = express.Router();

//INDEX 
router.get("/",(req,res) => {
    res.send("GET for posts");
});
//SHOW 
router.get("/:id",(req,res) => {
    res.send("GET for post id");
});
//POST 
router.get("/",(req,res) => {
    res.send("POST for posts");
});
// DELETE 
router.get("/:id",(req,res) => {
    res.send("DELETE for posts id");
});

module.exports = router;