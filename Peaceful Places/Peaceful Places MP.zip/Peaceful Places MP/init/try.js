const mongoose = require("mongoose");
const data = require("./data"); // Ensure this is an array of objects
const Listing = require("../models/listing");

const MONGO_URL = "mongodb://127.0.0.1:27017/peacefulplaces";

async function main() {
    try {
        await mongoose.connect(MONGO_URL, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log("Connected to database");

        await initDB();
    } catch (err) {
        console.error("Connection error:", err);
    }
}

const initDB = async () => {
    try {
        await Listing.deleteMany({});
        await Listing.insertMany(data);
        console.log("Data was initialized");
    } catch (error) {
        console.error("Error initializing data:", error);
    }
};

main();
