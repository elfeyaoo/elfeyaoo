document.getElementById('weatherForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const pin = document.getElementById('weatherInput').value;
    const loader = document.getElementById('loader');
    const errorBox = document.getElementById('error_head');
    const results = document.getElementById('results');
    const mapContainer = document.getElementById('map');

    // Clear previous results and errors
    results.innerHTML = '';
    errorBox.textContent = '';
    mapContainer.style.display = 'none';

    // Show loader
    loader.style.display = 'block';

    try {
        // Fetch data from the postal code API
        const res = await fetch(`https://api.postalpincode.in/pincode/${pin}`);
        const data = await res.json();

        if (!data || !data[0].PostOffice) {
            throw new Error("Invalid PIN or no data found.");
        }

        // Get post office data and display it in cards
        const postOffices = data[0].PostOffice;
        results.innerHTML = postOffices.map(p => `
            <div class="result-card">
                <div class="card-header">
                    <strong>${p.Name}</strong> (${p.BranchType})
                </div>
                <div class="card-body">
                    <div class="subcard">
                        <strong>District:</strong> ${p.District}
                    </div>
                    <div class="subcard">
                        <strong>State:</strong> ${p.State}
                    </div>
                    <div class="subcard">
                        <strong>Pincode:</strong> ${p.Pincode}
                    </div>
                </div>
            </div>
        `).join('');

        // Show the map with the first post office's coordinates
        const lat = parseFloat(postOffices[0].Latitude) || 19.0760; // fallback to Mumbai
        const lon = parseFloat(postOffices[0].Longitude) || 72.8777;
        mapContainer.style.display = 'block';

        // Initialize the map
        const map = L.map('map').setView([lat, lon], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Add markers for each post office
        postOffices.forEach(p => {
            if (p.Latitude && p.Longitude) {
                L.marker([p.Latitude, p.Longitude])
                    .addTo(map)
                    .bindPopup(`<b>${p.Name}</b><br>${p.BranchType}`);
            }
        });
    } catch (err) {
        errorBox.textContent = 'Error fetching data: ' + err.message;
    } finally {
        loader.style.display = 'none';
    }
});


// // Dark mode toggle functionality
// document.getElementById('themeToggle').addEventListener('change', function () {
//     // Toggle 'dark' class on the body element
//     document.body.classList.toggle('dark');
// });

// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyDp7AHduvPuNDnjXyp--JfZyK638NcaFdk",
//   authDomain: "postalservice-34616.firebaseapp.com",
//   projectId: "postalservice-34616",
//   storageBucket: "postalservice-34616.firebasestorage.app",
//   messagingSenderId: "447402571279",
//   appId: "1:447402571279:web:7508cd913c94cfb45e957a",
//   measurementId: "G-53HXDY7941"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);