from flask import Flask, render_template, request
import requests
import json
import os
import time  # for delay if needed

os.environ.setdefault('GOOGLE_CLOUD_PROJECT', 'serverless-cfe-455803')

app = Flask(__name__)

def get_coordinates(location_name):
    """Get latitude and longitude for a given location using OpenStreetMap."""
    base_url = "https://nominatim.openstreetmap.org/search"
    headers = {'User-Agent': 'MyGeoApp/1.0 (contact: example@email.com)'}  # Update with your contact

    try:
        # First try full query
        params = {
            'q': location_name,
            'format': 'json',
            'limit': 1,
            'countrycodes': 'in'  # Restrict to India
        }
        res = requests.get(base_url, params=params, headers=headers)
        results = res.json()

        if not results:
            # Try fallback: only district + state
            fallback_query = ", ".join(location_name.split(",")[-2:])  # "Ratnagiri, Maharashtra"
            params['q'] = fallback_query
            fallback_res = requests.get(base_url, params=params, headers=headers)
            results = fallback_res.json()
            if not results:
                print(f"[⚠️] No geolocation found for: {location_name}")
                return None, None

        return float(results[0]['lat']), float(results[0]['lon'])

    except Exception as e:
        print(f"[❌] Geolocation error for {location_name}: {e}")
        return None, None


@app.route("/", methods=["GET", "POST"])
def main():
    if request.method == "POST":
        pincode = request.form.get("zipCode", "").strip()

        if not pincode.isdigit() or len(pincode) != 6:
            return render_template("index.html", error="Please enter a valid 6-digit PIN code.")

        api_url = f"https://api.postalpincode.in/pincode/{pincode}"
        try:
            response = requests.get(api_url)
            data = response.json()
        except Exception as e:
            return render_template("index.html", error="Failed to retrieve data. Please try again later.")

        if data and data[0]["Status"] == "Success":
            post_offices = data[0]["PostOffice"]
            if not post_offices:
                return render_template("index.html", error="No post offices found for this PIN code.")

            enriched_post_offices = []
            for office in post_offices:
                location_string = f"{office['Name']}, {office['Division']}, {office['State']}"
                lat, lon = get_coordinates(location_string)

                # Only include offices with valid coordinates
                if lat is not None and lon is not None:
                    office['Latitude'] = lat
                    office['Longitude'] = lon
                    enriched_post_offices.append(office)

                # Optional: pause to avoid rate limit
                time.sleep(1)

            if not enriched_post_offices:
                return render_template("index.html", error="Unable to geolocate any nearby post offices.")

            # Use first enriched office for map center and info
            main_office = enriched_post_offices[0]
            name = main_office.get('Name', 'N/A')
            block = main_office.get('Block', 'N/A')
            district = main_office.get('District', 'N/A')
            state = main_office.get('State', 'N/A')
            lat = main_office.get('Latitude')
            lon = main_office.get('Longitude')

            return render_template("results.html",
                post_office=state,
                name=name,
                block=block,
                district=district,
                post_offices=enriched_post_offices,  # not raw post_offices
                post_offices_json=json.dumps(enriched_post_offices),
                latitude=lat or 20.5937,
                longitude=lon or 78.9629
            )
        else:
            return render_template("index.html", error="No results found for this PIN code.")

    return render_template("index.html")

if __name__ == "__main__":
    from waitress import serve
    print("Starting server on http://localhost:8080")
    serve(app, host="0.0.0.0", port=8080)
